<?php include 'includes/header.php';?>
        <!-- Navigation Bar -->
   <?php include 'includes/navbar.php';?>
        <!-- Navigation Bar -->

    <div class="container">
        <div class="row">
	        <!-- Page Content -->
	        <div class="col-md-8">
            <h1 class="page-header">Algebra backend developer tečaj </h1>
            
            <br>
            Ovo je primjer jednostavnog CMS sustava!<br><br><br>




           
           Karakteristike:
           <br><br>
           # Istovremeni pristup više korisnika <br>
           # Administratorski panel <br>
           # Korisnici putem CRUD sustava mogu manipulirati svojim objavama <br>
           # Siguran login i registracija <br>
           # Pretraga objava 
           <br><br><br>

           Pri izradi korišteni HTML, CSS, PHP i MySQL
           <br><br><br>

           <br>
           <br>



        </div>

             <div class="col-md-4">

               <?php include 'includes/sidebar.php';
?><!-- Footer -->
</div>
</div>
</div>
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>

</body>
</html>